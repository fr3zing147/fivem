# ZenDev GangBuilder
🔫 GangBuilder for FiveM

## v1.0

- Create on ESX Legacy 1.9.1 with oxmysql
- Menus in RageUI V3
- Create and edit without reboot
- Manage ranks (create, delete, rename) in boss menu
- Permissions system (garage access, inventory access etc)
- Inventory for items, weapons and accounts
- System discord logs (actions admin and actions players)
- Custom Data "gang" which prevent to use job or job 2
- Custom Data set up in ESX PlayerData

## VIDEO PREVIEW
[PREVIEW](https://www.youtube.com/watch?v=gm8JmkpamxU)
